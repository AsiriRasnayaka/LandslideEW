import React from 'react';
import { Dashboard } from './pages/Dashboard';
export function App() {
  return <Dashboard />;
}